package br.com.lhamalog.notificacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LhamalogNotificacaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LhamalogNotificacaoApplication.class, args);
	}

}
