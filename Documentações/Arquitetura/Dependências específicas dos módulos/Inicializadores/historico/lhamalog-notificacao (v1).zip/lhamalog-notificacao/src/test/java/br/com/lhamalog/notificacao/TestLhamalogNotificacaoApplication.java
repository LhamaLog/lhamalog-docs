package br.com.lhamalog.notificacao;

import org.springframework.boot.SpringApplication;

public class TestLhamalogNotificacaoApplication {

	public static void main(String[] args) {
		SpringApplication.from(LhamalogNotificacaoApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
