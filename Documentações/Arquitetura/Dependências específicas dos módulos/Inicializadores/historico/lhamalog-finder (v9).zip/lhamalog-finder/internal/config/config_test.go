package config

import "testing"

func TestCarregarPadrao(t *testing.T) {
	t.Setenv("FINDER_HTTP_ADDR", "")
	t.Setenv("FINDER_WORKERS", "")
	c := Carregar()
	if c.HTTPAddr != ":8085" || c.Workers != 4 {
		t.Fatalf("config inesperada: %+v", c)
	}
}

func TestCarregarWorkers(t *testing.T) {
	t.Setenv("FINDER_WORKERS", "8")
	if c := Carregar(); c.Workers != 8 {
		t.Fatalf("workers = %d", c.Workers)
	}
}

func TestCarregarVectorStorePadrao(t *testing.T) {
	t.Setenv("FINDER_ELASTICSEARCH_URL", "")
	t.Setenv("FINDER_VECTOR_INDEX_ALIAS", "")
	t.Setenv("FINDER_EMBEDDING_DIMS", "")
	v := Carregar().Vetores
	if len(v.ElasticsearchURLs) != 1 || v.ElasticsearchURLs[0] != "http://localhost:9200" ||
		v.IndexAlias != "lhamalog-finder-vectors" || v.EmbeddingDims != 0 {
		t.Fatalf("config do vector store inesperada: %+v", v)
	}
}

func TestCarregarVectorStoreEnv(t *testing.T) {
	t.Setenv("FINDER_ELASTICSEARCH_URL", "http://es1:9200,http://es2:9200")
	t.Setenv("FINDER_VECTOR_INDEX_ALIAS", "outro-alias")
	t.Setenv("FINDER_EMBEDDING_DIMS", "768")
	v := Carregar().Vetores
	if len(v.ElasticsearchURLs) != 2 || v.IndexAlias != "outro-alias" || v.EmbeddingDims != 768 {
		t.Fatalf("config do vector store inesperada: %+v", v)
	}
}
