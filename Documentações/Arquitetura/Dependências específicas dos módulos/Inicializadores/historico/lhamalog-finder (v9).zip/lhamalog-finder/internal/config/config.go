// Package config carrega a configuração por variáveis de ambiente.
package config

import (
	"os"
	"strconv"
	"strings"
)

// Config reúne as configurações do Finder.
type Config struct {
	HTTPAddr string
	Workers  int
	Vetores  VectorStore
}

// VectorStore configura o banco vetorial (Elasticsearch, ADR_152).
type VectorStore struct {
	ElasticsearchURLs []string // FINDER_ELASTICSEARCH_URL (vírgula separa vários nós)
	Username          string   // FINDER_ELASTICSEARCH_USERNAME (opcional)
	Password          string   // FINDER_ELASTICSEARCH_PASSWORD (opcional)
	IndexAlias        string   // FINDER_VECTOR_INDEX_ALIAS
	EmbeddingDims     int      // FINDER_EMBEDDING_DIMS (0 = inferido pelo 1º vetor)
}

// Carregar lê as variáveis de ambiente com valores padrão.
func Carregar() Config {
	c := Config{HTTPAddr: valor("FINDER_HTTP_ADDR", ":8085"), Workers: 4}
	if n, err := strconv.Atoi(os.Getenv("FINDER_WORKERS")); err == nil && n > 0 {
		c.Workers = n
	}
	c.Vetores = VectorStore{
		ElasticsearchURLs: strings.Split(valor("FINDER_ELASTICSEARCH_URL", "http://localhost:9200"), ","),
		Username:          os.Getenv("FINDER_ELASTICSEARCH_USERNAME"),
		Password:          os.Getenv("FINDER_ELASTICSEARCH_PASSWORD"),
		IndexAlias:        valor("FINDER_VECTOR_INDEX_ALIAS", "lhamalog-finder-vectors"),
	}
	if n, err := strconv.Atoi(os.Getenv("FINDER_EMBEDDING_DIMS")); err == nil && n > 0 {
		c.Vetores.EmbeddingDims = n
	}
	return c
}

func valor(chave, padrao string) string {
	if v := os.Getenv(chave); v != "" {
		return v
	}
	return padrao
}
