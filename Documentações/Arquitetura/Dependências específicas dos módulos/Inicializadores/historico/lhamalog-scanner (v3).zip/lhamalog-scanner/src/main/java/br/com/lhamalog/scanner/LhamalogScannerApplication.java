package br.com.lhamalog.scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LhamalogScannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LhamalogScannerApplication.class, args);
	}

}
