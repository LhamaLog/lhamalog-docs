package br.com.lhamalog.scanner;

import org.springframework.boot.SpringApplication;

public class TestLhamalogScannerApplication {

	public static void main(String[] args) {
		SpringApplication.from(LhamalogScannerApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
