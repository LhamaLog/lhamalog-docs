package br.com.lhamalog.notification;

import org.springframework.boot.SpringApplication;

public class TestLhamalogNotificationApplication {

	public static void main(String[] args) {
		SpringApplication.from(LhamalogNotificationApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
