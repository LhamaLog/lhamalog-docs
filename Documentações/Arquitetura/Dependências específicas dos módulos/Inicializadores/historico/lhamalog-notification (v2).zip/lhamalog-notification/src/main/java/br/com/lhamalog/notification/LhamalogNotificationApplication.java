package br.com.lhamalog.notification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LhamalogNotificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(LhamalogNotificationApplication.class, args);
	}

}
