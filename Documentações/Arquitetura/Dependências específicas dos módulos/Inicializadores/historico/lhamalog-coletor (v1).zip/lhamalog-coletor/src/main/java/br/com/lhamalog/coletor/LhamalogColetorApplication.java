package br.com.lhamalog.coletor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LhamalogColetorApplication {

	public static void main(String[] args) {
		SpringApplication.run(LhamalogColetorApplication.class, args);
	}

}
