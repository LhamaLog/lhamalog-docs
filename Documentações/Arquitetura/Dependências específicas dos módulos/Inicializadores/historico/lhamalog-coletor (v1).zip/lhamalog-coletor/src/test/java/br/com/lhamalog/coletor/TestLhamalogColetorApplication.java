package br.com.lhamalog.coletor;

import org.springframework.boot.SpringApplication;

public class TestLhamalogColetorApplication {

	public static void main(String[] args) {
		SpringApplication.from(LhamalogColetorApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
