// Package llm: camada adaptador/saida/llm (hexagonal leve). A implementar.
package llm
