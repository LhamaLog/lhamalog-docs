// Package elastic: camada adaptador/saida/elastic (hexagonal leve). A implementar.
package elastic
