// Package mongo: camada adaptador/saida/mongo (hexagonal leve). A implementar.
package mongo
