// Package aplicacao: camada aplicacao (hexagonal leve). A implementar.
package aplicacao
