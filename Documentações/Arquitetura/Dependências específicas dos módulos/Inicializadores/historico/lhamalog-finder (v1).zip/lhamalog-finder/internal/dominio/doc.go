// Package dominio: camada dominio (hexagonal leve). A implementar.
package dominio
