// Package entrada: camada aplicacao/porta/entrada (hexagonal leve). A implementar.
package entrada
