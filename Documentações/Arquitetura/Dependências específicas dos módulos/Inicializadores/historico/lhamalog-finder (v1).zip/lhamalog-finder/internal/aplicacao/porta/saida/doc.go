// Package saida: camada aplicacao/porta/saida (hexagonal leve). A implementar.
package saida
