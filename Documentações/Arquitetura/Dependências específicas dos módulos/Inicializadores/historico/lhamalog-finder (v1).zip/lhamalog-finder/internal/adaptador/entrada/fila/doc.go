// Package fila: camada adaptador/entrada/fila (hexagonal leve). A implementar.
package fila
