# lhamalog-finder

Módulo Finder do LhamaLog, em Go (LLT-259). Arquitetura hexagonal leve.

> **[PENDENTE] org do GitHub:** o módulo está como `github.com/ORG_PENDENTE/lhamalog-finder`.
> Ao definir a org: `go mod edit -module github.com/<org>/lhamalog-finder` e troque os imports
> (`grep -rl ORG_PENDENTE . | xargs sed -i 's#ORG_PENDENTE#<org>#g'`).

## Pré-requisitos
- Go 1.27.x
- Docker + Docker Compose
- make

## Como executar
1. Extraia este zip na raiz do repositório.
2. Ajuste o módulo/org (acima).
3. `make infra-up` sobe MongoDB, Redis e Elasticsearch locais.
4. `make run` (equivale a `go run ./cmd/finder`). Health em http://localhost:8085/health
5. `make test` (equivale a `go test -race ./...`).

Outros alvos: `make build` (bin/finder), `make lint` (go vet + golangci-lint opcional),
`make docker` (imagem multi-stage), `make infra-down`.

Variáveis: `FINDER_HTTP_ADDR` (padrão `:8085`), `FINDER_WORKERS` (padrão 4).
Sem GitHub Actions: rode `make test` localmente antes de cada push.

## Layout
```
cmd/finder/                      main (wiring, shutdown gracioso)
internal/dominio/                entidades e regras
internal/aplicacao/              casos de uso
internal/aplicacao/porta/        portas de entrada e saída
internal/adaptador/entrada/fila/ consumidor Redis Streams
internal/adaptador/entrada/http/ health interno
internal/adaptador/saida/{mongo,elastic,llm}/
internal/config/                 configuração por variáveis de ambiente
```

## Dependências candidatas (ainda não adicionadas)
Consulte o doc "Dependências - lhamalog-finder" antes de adicionar qualquer dependência.
- github.com/redis/go-redis/v9 — Redis Streams
- go.mongodb.org/mongo-driver/v2 — MongoDB
- github.com/elastic/go-elasticsearch/v9 — Elasticsearch
- go.opentelemetry.io/otel (+ sdk, exporters OTLP) — observabilidade
- golang.org/x/sync (errgroup, semaphore) — concorrência
- github.com/testcontainers/testcontainers-go — testes de integração
- LLM / BancoVetorial — [PENDENTE]

Plano: https://docs.google.com/document/d/18hcyacNpr5He6iO5tbGKygRPP3U884lwJbHOylsouD8/edit
