// Comando finder: ponto de entrada do módulo Finder do LhamaLog.
package main

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	httpadp "github.com/ORG_PENDENTE/lhamalog-finder/internal/adaptador/entrada/http"
	"github.com/ORG_PENDENTE/lhamalog-finder/internal/config"
)

func main() {
	log := slog.New(slog.NewJSONHandler(os.Stdout, nil))
	cfg := config.Carregar()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	srv := &http.Server{Addr: cfg.HTTPAddr, Handler: httpadp.NovoRoteador(), ReadHeaderTimeout: 5 * time.Second}
	go func() {
		log.Info("finder iniciado", "addr", cfg.HTTPAddr, "workers", cfg.Workers)
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Error("falha no servidor HTTP", "erro", err)
			stop()
		}
	}()

	<-ctx.Done()
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	_ = srv.Shutdown(shutdownCtx)
	log.Info("finder encerrado")
}
