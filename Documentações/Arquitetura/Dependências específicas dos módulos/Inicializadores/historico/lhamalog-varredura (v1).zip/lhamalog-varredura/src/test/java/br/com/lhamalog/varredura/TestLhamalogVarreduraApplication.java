package br.com.lhamalog.varredura;

import org.springframework.boot.SpringApplication;

public class TestLhamalogVarreduraApplication {

	public static void main(String[] args) {
		SpringApplication.from(LhamalogVarreduraApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
