package br.com.lhamalog.varredura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LhamalogVarreduraApplication {

	public static void main(String[] args) {
		SpringApplication.run(LhamalogVarreduraApplication.class, args);
	}

}
