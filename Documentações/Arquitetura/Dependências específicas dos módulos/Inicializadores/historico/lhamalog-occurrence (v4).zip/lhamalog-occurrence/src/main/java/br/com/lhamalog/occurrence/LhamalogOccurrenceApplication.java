package br.com.lhamalog.occurrence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LhamalogOccurrenceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LhamalogOccurrenceApplication.class, args);
	}

}
