package br.com.lhamalog.occurrence;

import org.springframework.boot.SpringApplication;

public class TestLhamalogOccurrenceApplication {

	public static void main(String[] args) {
		SpringApplication.from(LhamalogOccurrenceApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
