package br.com.lhamalog.ocorrencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LhamalogOcorrenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LhamalogOcorrenciaApplication.class, args);
	}

}
