package br.com.lhamalog.ocorrencia;

import org.springframework.boot.SpringApplication;

public class TestLhamalogOcorrenciaApplication {

	public static void main(String[] args) {
		SpringApplication.from(LhamalogOcorrenciaApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
