﻿# POC OpenObserve â€” LhamaLog

Teste do OpenObserve como substituto do Elasticsearch: ingestÃ£o (JSON e OTLP), busca de texto livre e isolamento por cliente (uma org por tenant).

## Subir
```powershell
docker compose up -d
```
UI: http://localhost:5080 (login = `ZO_ROOT_USER_EMAIL` / `ZO_ROOT_USER_PASSWORD` do `.env`).

## Enviar os logs de exemplo
```powershell
.\scripts\ingest.ps1      # ou: bash scripts/ingest.sh
```
- `sample-logs/tenant_a.json` â†’ org `tenant_a`, stream `app_logs`
- `sample-logs/tenant_b.json` â†’ org `tenant_b`, stream `app_logs`
- `sample-logs/otlp_tenant_a.json` â†’ OTLP pelo Collector (porta 14318 no host; 4317/4318 ficam livres para o coletor do LhamaLog) â†’ org `default`, stream `otel_logs`
- `.jsonl` = mesmo conteÃºdo em JSON Lines

## Buscar
```powershell
.\scripts\search.ps1      # ou: bash scripts/search.sh
```
Faz: texto livre (`match_all('timeout')`), agregaÃ§Ã£o por nÃ­vel e prova de isolamento entre tenants. Na UI: Logs â†’ escolha a org no canto superior.

## Medir compressÃ£o
UI â†’ Streams: compare "Original size" Ã— "Compressed size" de cada stream.

## PrÃ³ximo passo: bucket da Magalu
Descomente o bloco `ZO_S3_*` no `docker-compose.yml`, crie o bucket e as chaves na MGC e suba de novo.

## Limpar
```powershell
docker compose down; Remove-Item -Recurse -Force .\data
```
> Imagem em `latest` para o 1Âº teste; depois fixe a versÃ£o. Senha do `.env` Ã© sÃ³ de exemplo.
