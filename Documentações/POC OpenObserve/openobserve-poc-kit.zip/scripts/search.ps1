﻿Set-Location (Join-Path $PSScriptRoot '..')
$env = @{}; Get-Content .env | ? { $_ -match '^\s*[^#].*=' } | % { $k,$v = $_ -split '=',2; $env[$k.Trim()] = $v.Trim() }
$auth = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("$($env.ZO_ROOT_USER_EMAIL):$($env.ZO_ROOT_USER_PASSWORD)"))
$end = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() * 1000; $start = $end - (30 * 86400000000)  # ultimos 30 dias
function Q($org, $sql) {
  $body = @{ query = @{ sql = $sql; start_time = $start; end_time = $end; from = 0; size = 5 } } | ConvertTo-Json -Depth 5
  Invoke-RestMethod -Method Post -Uri "http://localhost:5080/api/$org/_search" -Headers @{Authorization=$auth} -ContentType 'application/json' -Body $body | ConvertTo-Json -Depth 6
}
"== Texto livre 'timeout' no tenant_a"; Q 'tenant_a' "SELECT * FROM `"app_logs`" WHERE match_all('timeout')"
"== Contagem por nivel no tenant_b";    Q 'tenant_b' "SELECT level, count(*) AS total FROM `"app_logs`" GROUP BY level"
"== Isolamento (deve vir 0)";           Q 'tenant_b' "SELECT count(*) AS total FROM `"app_logs`" WHERE service='checkout-api'"
