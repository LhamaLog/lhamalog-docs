﻿#!/usr/bin/env bash
set -e; cd "$(dirname "$0")/.."; source .env
U="$ZO_ROOT_USER_EMAIL:$ZO_ROOT_USER_PASSWORD"
END=$(( $(date +%s) * 1000000 )); START=$(( END - 30 * 86400000000 ))
q(){ curl -s -u "$U" -X POST "http://localhost:5080/api/$1/_search" -H 'Content-Type: application/json' \
  -d "{\"query\":{\"sql\":\"$2\",\"start_time\":$START,\"end_time\":$END,\"from\":0,\"size\":5}}"; echo; echo; }
echo "== Texto livre 'timeout' no tenant_a";  q tenant_a "SELECT * FROM \\\"app_logs\\\" WHERE match_all('timeout')"
echo "== Contagem por nÃ­vel no tenant_b";     q tenant_b "SELECT level, count(*) AS total FROM \\\"app_logs\\\" GROUP BY level"
echo "== Isolamento: tenant_b NÃƒO vÃª checkout-api (deve vir 0)"; q tenant_b "SELECT count(*) AS total FROM \\\"app_logs\\\" WHERE service='checkout-api'"
