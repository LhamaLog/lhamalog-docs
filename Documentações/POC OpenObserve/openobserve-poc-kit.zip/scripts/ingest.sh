﻿#!/usr/bin/env bash
# Envia cada tenant para uma ORG separada (isolamento multi-tenant)
set -e; cd "$(dirname "$0")/.."; source .env
U="$ZO_ROOT_USER_EMAIL:$ZO_ROOT_USER_PASSWORD"
for t in tenant_a tenant_b; do
  curl -s -u "$U" -X POST "http://localhost:5080/api/$t/app_logs/_json" -H 'Content-Type: application/json' --data-binary @sample-logs/$t.json; echo
done
# Via OTLP (passa pelo OTel Collector -> org default, stream otel_logs)
curl -s -X POST http://localhost:14318/v1/logs -H 'Content-Type: application/json' --data-binary @sample-logs/otlp_tenant_a.json; echo
