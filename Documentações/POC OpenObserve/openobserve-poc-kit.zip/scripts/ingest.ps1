﻿Set-Location (Join-Path $PSScriptRoot '..')
$env = @{}; Get-Content .env | ? { $_ -match '^\s*[^#].*=' } | % { $k,$v = $_ -split '=',2; $env[$k.Trim()] = $v.Trim() }
$auth = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("$($env.ZO_ROOT_USER_EMAIL):$($env.ZO_ROOT_USER_PASSWORD)"))
foreach ($t in 'tenant_a','tenant_b') {
  Invoke-RestMethod -Method Post -Uri "http://localhost:5080/api/$t/app_logs/_json" -Headers @{Authorization=$auth} -ContentType 'application/json' -InFile "sample-logs\$t.json"
}
Invoke-RestMethod -Method Post -Uri 'http://localhost:14318/v1/logs' -ContentType 'application/json' -InFile 'sample-logs\otlp_tenant_a.json'
